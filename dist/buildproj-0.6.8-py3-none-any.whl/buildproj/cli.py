def start():
  from buildproj import launch

  launch()
